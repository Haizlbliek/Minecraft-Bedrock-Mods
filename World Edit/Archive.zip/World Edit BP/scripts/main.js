import { world, system, BlockPermutation } from "@minecraft/server";
import { MinecraftBlockTypes } from 'vanilla.js';

function setBlock(blockData, type) {
    const block = blockData.dimension.getBlock(blockData.location);

    if (!block) {
        return;
    }

    const permutation = BlockPermutation.resolve(type);
    block.setPermutation(permutation);
}

function randomname() {
	const letters = "abcdefghijklmnopqrstuvwxyz";
	let name = "";

	for (let i = 0; i < 20; i++) {
		name += letters[Math.floor(Math.random() * letters.length)];
	}

	return name;
}

world.afterEvents.playerPlaceBlock.subscribe((event) => {
	// world.sendMessage("Place!");
	// setBlock(event.block, MinecraftBlockTypes.AmethystBlock)
	for (let player of world.getAllPlayers()) {
		player.nameTag = randomname();
	}
});